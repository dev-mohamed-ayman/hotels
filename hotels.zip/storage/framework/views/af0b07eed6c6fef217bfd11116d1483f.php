<style>
    .custom-toast-height {
        position: relative !important;
        height: auto !important;
        padding: 0px 12px !important;
        font-size: 14px !important;
        line-height: 1.2 !important;

        & * {
            cursor: pointer !important;
        }

    }

</style>
<script>
    window.toast = function (type = 'success', message = '', opts = {}) {
        const Toast = Swal.mixin({
            toast: true,
            position: opts.position || 'bottom-<?php echo e(app()->getLocale() == 'ar' ? 'left' : 'right'); ?>',
            showConfirmButton: false,
            timer: opts.timer || 2500,
            timerProgressBar: true,
            customClass: {
                popup: 'custom-toast-height'
            },
            didOpen: (toast) => {
                toast.style.cursor = 'pointer';
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
                toast.addEventListener('click', () => Swal.close());
            }
        });
        return Toast.fire({icon: type, title: message});
    };
    <?php if(session('success')): ?>
    window.toast('success', <?php echo json_encode(session('success'), 15, 512) ?>);
    <?php endif; ?>

    <?php if(session('error')): ?>
    window.toast('error', <?php echo json_encode(session('error'), 15, 512) ?>);
    <?php endif; ?>

    <?php if(session('warning')): ?>
    window.toast('warning', <?php echo json_encode(session('warning'), 15, 512) ?>);
    <?php endif; ?>

    <?php if(session('info')): ?>
    window.toast('info', <?php echo json_encode(session('info'), 15, 512) ?>);
    <?php endif; ?>
</script>
<?php /**PATH C:\Users\Mohamed Ayman\Herd\hotels\resources\views/admin/layouts/toast.blade.php ENDPATH**/ ?>