<?php $__env->startSection('title', __('Dashboard')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Upcoming Option Dates -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($upcomingOptionDates->isNotEmpty()): ?>
        <div class="row g-4 mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center gap-2">
                            <h5 class="mb-0"><?php echo e(__('Upcoming Option Dates')); ?></h5>
                            <span class="badge bg-label-warning"><?php echo e(__('Next 7 Days')); ?></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover text-center table-sm" style="font-size: 0.875rem;">
                                <thead>
                                    <tr>
                                        <th class="text-nowrap"><?php echo e(__('Code')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Hotel')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Rooms')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Check In')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Check Out')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Nights')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Total Net')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Paid Net')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Remaining Net')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Option Date')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Status')); ?></th>
                                        <th class="text-nowrap"><?php echo e(__('Actions')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $upcomingOptionDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-nowrap py-2"><strong><?php echo e($booking->code); ?></strong></td>
                                            <td class="text-nowrap py-2"><?php echo e($booking->hotel->name); ?></td>
                                            <td class="py-2" style="width: 130px;">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->rooms && $booking->rooms->count() > 0): ?>
                                                    <?php
                                                        $roomTypes = ['SGL' => 0, 'DBL' => 0, 'TPL' => 0, 'QUD' => 0];
                                                        $totalRooms = 0;
                                                        foreach ($booking->rooms as $room) {
                                                            $roomTypes[$room->room_type] += $room->room_count;
                                                            $totalRooms += $room->room_count;
                                                        }
                                                    ?>
                                                    <div class="text-start" style="line-height: 1.4;">
                                                        <div class="mb-1">
                                                            <strong class="text-primary"><?php echo e($totalRooms); ?></strong>
                                                            <small
                                                                class="text-muted"><?php echo e($totalRooms == 1 ? __('Room') : __('Rooms')); ?></small>
                                                        </div>
                                                        <div class="d-flex flex-wrap gap-1">
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['SGL', 'DBL', 'TPL', 'QUD']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($roomTypes[$type] > 0): ?>
                                                                    <span class="badge bg-label-info"
                                                                        style="font-size: 0.7rem; padding: 0.15rem 0.35rem; line-height: 1.2;">
                                                                        <?php echo e($roomTypes[$type]); ?>

                                                                        <strong><?php echo e($type); ?></strong>
                                                                    </span>
                                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                            <td class="text-nowrap py-2"><?php echo e($booking->check_in->format('d-m-Y')); ?></td>
                                            <td class="text-nowrap py-2"><?php echo e($booking->check_out->format('d-m-Y')); ?></td>
                                            <td class="text-nowrap py-2"><?php echo e($booking->nights); ?></td>
                                            <td class="text-nowrap py-2">
                                                <?php echo e($booking->net_amount == 0 ? '' : $booking->currency->symbol . ' ' . number_format($booking->net_amount, 0)); ?>

                                            </td>
                                            <td class="text-nowrap py-2">
                                                <span class="fw-semibold text-success">
                                                    <?php echo e($booking->hotel_paid_amount == 0 ? '' : $booking->currency->symbol . ' ' . number_format($booking->hotel_paid_amount, 0)); ?>

                                                </span>
                                            </td>
                                            <td class="text-nowrap py-2">
                                                <?php
                                                    $remaining = $booking->net_amount - $booking->hotel_paid_amount;
                                                ?>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($remaining > 0): ?>
                                                    <span class="fw-semibold text-danger">
                                                        <?php echo e($booking->currency->symbol); ?>

                                                        <?php echo e(number_format($remaining, 0)); ?>

                                                    </span>
                                                <?php elseif($booking->net_amount > 0): ?>
                                                    <span class="badge bg-label-success" style="font-size: 0.75rem;">
                                                        <i class="ti tabler-check me-1"></i>
                                                        <?php echo e(__('Paid')); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>

                                            <td class="py-2">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->option_date): ?>
                                                    <div class="d-flex flex-column align-items-center gap-1">
                                                        <div class="d-flex align-items-center gap-1">
                                                            <i class="ti tabler-calendar-event text-primary"
                                                                style="font-size: 0.9rem;"></i>
                                                            <span
                                                                class="fw-semibold text-primary text-nowrap"><?php echo e($booking->option_date->format('d-m-Y')); ?></span>
                                                        </div>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($remaining <= 0): ?>
                                                            <span class="badge bg-label-success"
                                                                style="font-size: 0.75rem;">
                                                                <i class="ti tabler-check me-1"></i>
                                                                <?php echo e(__('Paid')); ?>

                                                            </span>
                                                        <?php else: ?>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->option_date->isPast()): ?>
                                                                <span class="badge bg-label-warning"
                                                                    style="font-size: 0.65rem;"><?php echo e(__('Past')); ?></span>
                                                            <?php elseif($booking->option_date->isToday()): ?>
                                                                <span class="badge bg-label-info"
                                                                    style="font-size: 0.65rem;"><?php echo e(__('Today')); ?></span>
                                                            <?php else: ?>
                                                                <span class="badge bg-label-success"
                                                                    style="font-size: 0.65rem;"><?php echo e(__('Upcoming')); ?></span>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                            <td class="text-nowrap py-2">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->status == 'confirmed'): ?>
                                                    <span class="badge bg-label-success"><?php echo e(__('Confirmed')); ?></span>
                                                <?php elseif($booking->status == 'pending'): ?>
                                                    <span class="badge bg-label-warning"><?php echo e(__('Pending')); ?></span>
                                                <?php else: ?>
                                                    <span class="badge bg-label-danger"><?php echo e(__('Cancelled')); ?></span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                            <td class="text-nowrap">
                                                <div class="dropdown">
                                                    <button class="btn btn-sm btn-icon btn-secondary" type="button"
                                                        id="upcomingActionsDropdown<?php echo e($booking->id); ?>"
                                                        data-bs-toggle="dropdown" aria-expanded="false"
                                                        style="padding: 0.25rem 0.5rem;">
                                                        <i class="ti tabler-dots-vertical" style="font-size: 0.9rem;"></i>
                                                    </button>
                                                    <ul class="dropdown-menu dropdown-menu-end"
                                                        aria-labelledby="upcomingActionsDropdown<?php echo e($booking->id); ?>">
                                                        <li>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('bookings.show', $booking)); ?>">
                                                                <i class="ti tabler-eye me-2"></i><?php echo e(__('View Details')); ?>

                                                            </a>
                                                        </li>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit bookings')): ?>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->check_in >= now()): ?>
                                                                <li>
                                                                    <a class="dropdown-item"
                                                                        href="<?php echo e(route('bookings.edit', $booking)); ?>">
                                                                        <i class="ti tabler-edit me-2"></i><?php echo e(__('Edit')); ?>

                                                                    </a>
                                                                </li>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <!-- Room Nights Production Chart -->
        <div class="col-xl-8 col-lg-7 col-12">
            <div class="card h-100">
                <div class="card-header header-elements">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Room Nights Production'); ?></h5>
                </div>
                <div class="card-body">
                    <canvas id="barChart" class="chartjs" data-height="400"></canvas>
                </div>
            </div>
        </div>

        <!-- Payment Status -->
        <div class="col-xl-4 col-lg-5 col-12">
            <div class="card h-100">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0"><?php echo e(__('Payment Status')); ?></h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-4 mt-2">
                        <div>
                            <p class="mb-1 text-muted"><?php echo e(__('Paid')); ?></p>
                            <h4 class="mb-0 text-success fw-bold">
                                <?php echo e($paidBookings == 0 ? '' : number_format($paidBookings)); ?></h4>
                        </div>
                        <div class="avatar avatar-lg">
                            <div class="avatar-initial bg-label-success rounded shadow-sm">
                                <i class="ti tabler-check ti-md"></i>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-4">
                        <div>
                            <p class="mb-1 text-muted"><?php echo e(__('Partial Payment')); ?></p>
                            <h4 class="mb-0 text-warning fw-bold">
                                <?php echo e($partialBookings == 0 ? '' : number_format($partialBookings)); ?></h4>
                        </div>
                        <div class="avatar avatar-lg">
                            <div class="avatar-initial bg-label-warning rounded shadow-sm">
                                <i class="ti tabler-alert-circle ti-md"></i>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            <p class="mb-1 text-muted"><?php echo e(__('Unpaid')); ?></p>
                            <h4 class="mb-0 text-danger fw-bold">
                                <?php echo e($unpaidBookings == 0 ? '' : number_format($unpaidBookings)); ?></h4>
                        </div>
                        <div class="avatar avatar-lg">
                            <div class="avatar-initial bg-label-danger rounded shadow-sm">
                                <i class="ti tabler-x ti-md"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Hotels by Sales -->
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0"><?php echo e(__('Top Hotels by Sales')); ?></h5>
                    <a href="<?php echo e(route('hotels.index')); ?>" class="btn btn-sm btn-label-primary"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Hotel')); ?></th>
                                    <th><?php echo e(__('Sales')); ?></th>
                                    <th><?php echo e(__('Paid')); ?></th>
                                    <th><?php echo e(__('Bookings')); ?></th>
                                    <th><?php echo e(__('Rooms')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $hotelsSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('hotels.show', $hotel['id'])); ?>" class="fw-semibold">
                                                <?php echo e($hotel['name']); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($hotel['total_sales'] == 0 ? '' : number_format($hotel['total_sales'], 0)); ?>

                                        </td>
                                        <td><?php echo e($hotel['paid_sales'] == 0 ? '' : number_format($hotel['paid_sales'], 0)); ?>

                                        </td>
                                        <td><span class="badge bg-label-primary"><?php echo e($hotel['bookings_count']); ?></span>
                                        </td>
                                        <td><span class="badge bg-label-info"><?php echo e($hotel['rooms_count']); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted">
                                            <?php echo e(__('No hotels found')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Bookings -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0"><?php echo e(__('Recent Bookings')); ?></h5>
                    <a href="<?php echo e(route('bookings.index')); ?>"
                        class="btn btn-sm btn-label-primary"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover text-center table-sm" style="font-size: 0.875rem;">
                            <thead>
                                <tr>
                                    <th class="text-nowrap"><?php echo e(__('Code')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Hotel')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Rooms')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Check In')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Check Out')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Nights')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Total Net')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Paid Net')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Remaining Net')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Option Date')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Status')); ?></th>
                                    <th class="text-nowrap"><?php echo e(__('Actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-nowrap py-2"><strong><?php echo e($booking->code); ?></strong></td>
                                        <td class="text-nowrap py-2"><?php echo e($booking->hotel->name); ?></td>
                                        <td class="py-2" style="width: 130px;">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->rooms && $booking->rooms->count() > 0): ?>
                                                <?php
                                                    $roomTypes = ['SGL' => 0, 'DBL' => 0, 'TPL' => 0, 'QUD' => 0];
                                                    $totalRooms = 0;
                                                    foreach ($booking->rooms as $room) {
                                                        $roomTypes[$room->room_type] += $room->room_count;
                                                        $totalRooms += $room->room_count;
                                                    }
                                                ?>
                                                <div class="text-start" style="line-height: 1.4;">
                                                    <div class="mb-1">
                                                        <strong class="text-primary"><?php echo e($totalRooms); ?></strong>
                                                        <small
                                                            class="text-muted"><?php echo e($totalRooms == 1 ? __('Room') : __('Rooms')); ?></small>
                                                    </div>
                                                    <div class="d-flex flex-wrap gap-1">
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['SGL', 'DBL', 'TPL', 'QUD']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($roomTypes[$type] > 0): ?>
                                                                <span class="badge bg-label-info"
                                                                    style="font-size: 0.7rem; padding: 0.15rem 0.35rem; line-height: 1.2;">
                                                                    <?php echo e($roomTypes[$type]); ?>

                                                                    <strong><?php echo e($type); ?></strong>
                                                                </span>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td class="text-nowrap py-2"><?php echo e($booking->check_in->format('d-m-Y')); ?></td>
                                        <td class="text-nowrap py-2"><?php echo e($booking->check_out->format('d-m-Y')); ?></td>
                                        <td class="text-nowrap py-2"><?php echo e($booking->nights); ?></td>
                                        <td class="text-nowrap py-2">
                                            <?php echo e($booking->net_amount == 0 ? '' : $booking->currency->symbol . ' ' . number_format($booking->net_amount, 0)); ?>

                                        </td>
                                        <td class="text-nowrap py-2">
                                            <span class="fw-semibold text-success">
                                                <?php echo e($booking->hotel_paid_amount == 0 ? '' : $booking->currency->symbol . ' ' . number_format($booking->hotel_paid_amount, 0)); ?>

                                            </span>
                                        </td>
                                        <td class="text-nowrap py-2">
                                            <?php
                                                $remaining = $booking->net_amount - $booking->hotel_paid_amount;
                                            ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($remaining > 0): ?>
                                                <span class="badge bg-label-danger" style="font-size: 0.75rem;">
                                                    <i class="ti tabler-alert-circle me-1"></i>
                                                    <?php echo e($booking->currency->symbol); ?> <?php echo e(number_format($remaining, 0)); ?>

                                                </span>
                                            <?php elseif($booking->net_amount > 0): ?>
                                                <span class="badge bg-label-success" style="font-size: 0.75rem;">
                                                    <i class="ti tabler-check me-1"></i>
                                                    <?php echo e(__('Paid')); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td class="py-2">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->option_date): ?>
                                                <div class="d-flex flex-column align-items-center gap-1">
                                                    <div class="d-flex align-items-center gap-1">
                                                        <i class="ti tabler-calendar-event text-primary"
                                                            style="font-size: 0.9rem;"></i>
                                                        <span
                                                            class="fw-semibold text-primary text-nowrap"><?php echo e($booking->option_date->format('d-m-Y')); ?></span>
                                                    </div>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($remaining <= 0): ?>
                                                        <span class="badge bg-label-success" style="font-size: 0.75rem;">
                                                            <i class="ti tabler-check me-1"></i>
                                                            <?php echo e(__('Paid')); ?>

                                                        </span>
                                                    <?php else: ?>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->option_date->isPast()): ?>
                                                            <span class="badge bg-label-warning"
                                                                style="font-size: 0.65rem;"><?php echo e(__('Past')); ?></span>
                                                        <?php elseif($booking->option_date->isToday()): ?>
                                                            <span class="badge bg-label-info"
                                                                style="font-size: 0.65rem;"><?php echo e(__('Today')); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge bg-label-success"
                                                                style="font-size: 0.65rem;"><?php echo e(__('Upcoming')); ?></span>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td class="text-nowrap py-2">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->hotel_paid_amount == 0): ?>
                                                <span class="badge bg-danger" title="<?php echo e(__('Unpaid')); ?>"
                                                    style="font-size: 0.75rem;">
                                                    <i class="ti tabler-x"></i>
                                                </span>
                                            <?php elseif($booking->hotel_paid_amount >= $booking->net_amount && $booking->net_amount > 0): ?>
                                                <span class="badge bg-success" title="<?php echo e(__('Paid')); ?>"
                                                    style="font-size: 0.75rem;">
                                                    <i class="ti tabler-check"></i>
                                                </span>
                                            <?php elseif($booking->net_amount > 0): ?>
                                                <span class="badge bg-warning" title="<?php echo e(__('Partial Payment')); ?>"
                                                    style="font-size: 0.75rem;">
                                                    <i class="ti tabler-question-mark"></i>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td class="text-nowrap">
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-icon btn-secondary" type="button"
                                                    id="actionsDropdown<?php echo e($booking->id); ?>" data-bs-toggle="dropdown"
                                                    aria-expanded="false" style="padding: 0.25rem 0.5rem;">
                                                    <i class="ti tabler-dots-vertical" style="font-size: 0.9rem;"></i>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end"
                                                    aria-labelledby="actionsDropdown<?php echo e($booking->id); ?>">
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('bookings.show', $booking)); ?>">
                                                            <i class="ti tabler-eye me-2"></i><?php echo e(__('View Details')); ?>

                                                        </a>
                                                    </li>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit bookings')): ?>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->check_in >= now()): ?>
                                                            <li>
                                                                <a class="dropdown-item"
                                                                    href="<?php echo e(route('bookings.edit', $booking)); ?>">
                                                                    <i class="ti tabler-edit me-2"></i><?php echo e(__('Edit')); ?>

                                                                </a>
                                                            </li>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        
                                                        <li>
                                                            <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                                data-bs-target="#hotelPaymentModal<?php echo e($booking->id); ?>">
                                                                <i
                                                                    class="ti tabler-building me-2"></i><?php echo e(__('Update Hotel Payment')); ?>

                                                            </a>
                                                        </li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete bookings')): ?>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->check_in >= now()): ?>
                                                            <li>
                                                                <hr class="dropdown-divider">
                                                            </li>
                                                            <li>
                                                                <form action="<?php echo e(route('bookings.destroy', $booking)); ?>"
                                                                    method="POST"
                                                                    onsubmit="return confirm('<?php echo e(__('Are you sure you want to delete this booking?')); ?>')">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit"
                                                                        class="dropdown-item text-danger w-100 text-start">
                                                                        <i
                                                                            class="ti tabler-trash me-2"></i><?php echo e(__('Delete')); ?>

                                                                    </button>
                                                                </form>
                                                            </li>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Payment Update Modal -->
                                    <div class="modal fade" id="paymentModal<?php echo e($booking->id); ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"><?php echo e(__('Update Payment')); ?> -
                                                        <?php echo e($booking->code); ?></h5>
                                                    <button type="button" class="btn-close"
                                                        data-bs-dismiss="modal"></button>
                                                </div>
                                                <form action="<?php echo e(route('bookings.update-payment', $booking)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label class="form-label"><?php echo e(__('Total Amount')); ?></label>
                                                            <input type="text" class="form-control"
                                                                value="<?php echo e($booking->total_amount == 0 ? '' : number_format($booking->total_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                                readonly>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label
                                                                class="form-label"><?php echo e(__('Current Paid Amount')); ?></label>
                                                            <input type="text" class="form-control"
                                                                value="<?php echo e($booking->paid_amount == 0 ? '' : number_format($booking->paid_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                                readonly>
                                                        </div>
                                                        <div class="mb-3">
                                                            <?php
                                                                $remaining =
                                                                    $booking->total_amount - $booking->paid_amount;
                                                            ?>
                                                            <label
                                                                class="form-label"><?php echo e(__('Remaining Amount')); ?></label>
                                                            <input type="text" class="form-control"
                                                                id="remaining<?php echo e($booking->id); ?>"
                                                                value="<?php echo e(number_format($remaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                                readonly>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label"
                                                                for="payment_amount<?php echo e($booking->id); ?>"><?php echo e(__('Payment Amount')); ?>

                                                                *</label>
                                                            <div class="input-group">
                                                                <input type="number" step="0.01" class="form-control"
                                                                    id="payment_amount<?php echo e($booking->id); ?>"
                                                                    name="payment_amount" min="1"
                                                                    max="<?php echo e($remaining); ?>" step="1"
                                                                    data-remaining="<?php echo e($remaining); ?>"
                                                                    data-currency="<?php echo e($booking->currency->symbol); ?>"
                                                                    data-booking-id="<?php echo e($booking->id); ?>"
                                                                    placeholder="<?php echo e(__('Enter amount to pay')); ?>"
                                                                    required>
                                                                <span
                                                                    class="input-group-text"><?php echo e($booking->currency->symbol); ?></span>
                                                            </div>
                                                            <small class="text-muted"><?php echo e(__('Maximum')); ?>:
                                                                <?php echo e(number_format($remaining, 0)); ?>

                                                                <?php echo e($booking->currency->symbol); ?></small>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label
                                                                class="form-label"><?php echo e(__('New Remaining Amount')); ?></label>
                                                            <input type="text" class="form-control"
                                                                id="new_remaining<?php echo e($booking->id); ?>"
                                                                value="<?php echo e(number_format($remaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                                readonly>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                    </div>

                    <!-- Hotel Payment Update Modal -->
                    <div class="modal fade" id="hotelPaymentModal<?php echo e($booking->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title"><?php echo e(__('Update Hotel Payment')); ?> -
                                        <?php echo e($booking->code); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form action="<?php echo e(route('bookings.update-hotel-payment', $booking)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label class="form-label"><?php echo e(__('Total Net Amount')); ?></label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e($booking->net_amount == 0 ? '' : number_format($booking->net_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                readonly>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><?php echo e(__('Paid to Hotel')); ?></label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e($booking->hotel_paid_amount == 0 ? '' : number_format($booking->hotel_paid_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                readonly>
                                        </div>
                                        <div class="mb-3">
                                            <?php
                                                $hotelRemaining = $booking->net_amount - $booking->hotel_paid_amount;
                                            ?>
                                            <label class="form-label"><?php echo e(__('Remaining Amount')); ?></label>
                                            <input type="text" class="form-control"
                                                id="hotel_remaining<?php echo e($booking->id); ?>"
                                                value="<?php echo e($hotelRemaining == 0 ? '' : number_format($hotelRemaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                readonly>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"
                                                for="hotel_payment_amount<?php echo e($booking->id); ?>"><?php echo e(__('Payment Amount')); ?>

                                                *</label>
                                            <div class="input-group">
                                                <input type="number" step="0.01" class="form-control"
                                                    id="hotel_payment_amount<?php echo e($booking->id); ?>" name="payment_amount"
                                                    min="0.01" max="<?php echo e(max($hotelRemaining, 0.01)); ?>"
                                                    data-remaining="<?php echo e($hotelRemaining); ?>"
                                                    data-currency="<?php echo e($booking->currency->symbol); ?>"
                                                    data-booking-id="<?php echo e($booking->id); ?>"
                                                    placeholder="<?php echo e(__('Enter amount to pay')); ?>" required>
                                                <span class="input-group-text"><?php echo e($booking->currency->symbol); ?></span>
                                            </div>
                                            <small class="text-muted"><?php echo e(__('Maximum')); ?>:
                                                <?php echo e(number_format(max($hotelRemaining, 0), 0)); ?>

                                                <?php echo e($booking->currency->symbol); ?></small>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><?php echo e(__('New Remaining Amount')); ?></label>
                                            <input type="text" class="form-control"
                                                id="new_hotel_remaining<?php echo e($booking->id); ?>"
                                                value="<?php echo e(number_format($hotelRemaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                readonly>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="12" class="text-center py-5">
                            <div class="d-flex flex-column align-items-center">
                                <i class="ti tabler-inbox" style="font-size: 3rem; color: #cbd5e0;"></i>
                                <p class="mt-3 text-muted"><?php echo e(__('No bookings found')); ?></p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities Widget -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view activity log')): ?>
        <div class="row g-4 mt-4">
            <div class="col-md-6">
                <?php echo $__env->make('admin.components.recent-activities', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/vendor/libs/chartjs/chartjs.js')); ?>"></script>
    <script src="<?php echo e(asset('assets//js/charts-chartjs-legend.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/charts-chartjs.js')); ?>"></script>

    <script>
        // Bar Chart - Room Nights Production (Top 5 Hotels)
        // --------------------------------------------------------------------
        document.addEventListener('DOMContentLoaded', function() {
            const barChart = document.getElementById('barChart');
            if (barChart) {
                // Get data from PHP
                const topHotelsData = <?php echo json_encode($topHotelsByRoomNights, 15, 512) ?>;

                // Extract hotel names and room nights production
                const hotelLabels = topHotelsData.map(hotel => hotel.name);
                const roomNightsData = topHotelsData.map(hotel => hotel.room_nights_production);

                // Calculate max value for Y axis (round up to nearest 50)
                const maxValue = Math.max(...roomNightsData, 1);
                const yAxisMax = Math.ceil(maxValue / 50) * 50; // Round up to nearest 50
                const stepSize = 50; // Fixed step size of 50

                // Color variables
                const cyanColor = '#28dac6';
                const isRtl = document.documentElement.dir === 'rtl';
                const isDarkStyle = window.Helpers ? window.Helpers.isDarkStyle() : false;
                const cardColor = window.Helpers ? window.Helpers.getCssVar('paper-bg', true) : '#fff';
                const headingColor = window.Helpers ? window.Helpers.getCssVar('heading-color', true) : '#5e5873';
                const labelColor = window.Helpers ? window.Helpers.getCssVar('secondary-color', true) : '#a8aaae';
                const legendColor = window.Helpers ? window.Helpers.getCssVar('body-color', true) : '#6e6b7b';
                const borderColor = window.Helpers ? window.Helpers.getCssVar('border-color', true) : '#ebe9f1';

                const barChartVar = new Chart(barChart, {
                    type: 'bar',
                    data: {
                        labels: hotelLabels,
                        datasets: [{
                            label: '<?php echo e(__('Room Nights Production')); ?>',
                            data: roomNightsData,
                            backgroundColor: cyanColor,
                            borderColor: 'transparent',
                            maxBarThickness: 15,
                            borderRadius: {
                                topRight: 15,
                                topLeft: 15
                            }
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        animation: {
                            duration: 500
                        },
                        plugins: {
                            tooltip: {
                                rtl: isRtl,
                                backgroundColor: cardColor,
                                titleColor: headingColor,
                                bodyColor: legendColor,
                                borderWidth: 1,
                                borderColor: borderColor,
                                callbacks: {
                                    label: function(context) {
                                        return '<?php echo e(__('Room Nights')); ?>: ' + context.parsed.y
                                            .toLocaleString();
                                    }
                                }
                            },
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            x: {
                                grid: {
                                    color: borderColor,
                                    drawBorder: false,
                                    borderColor: borderColor
                                },
                                ticks: {
                                    color: labelColor,
                                    maxRotation: 45,
                                    minRotation: 45
                                }
                            },
                            y: {
                                min: 0,
                                max: yAxisMax,
                                grid: {
                                    color: borderColor,
                                    drawBorder: false,
                                    borderColor: borderColor
                                },
                                ticks: {
                                    stepSize: stepSize,
                                    color: labelColor,
                                    callback: function(value) {
                                        return value.toLocaleString();
                                    }
                                }
                            }
                        }
                    }
                });
            }
        });

        // Payment Update Logic
        document.addEventListener('DOMContentLoaded', function() {
            // Get all payment amount inputs
            const paymentInputs = document.querySelectorAll('[id^="payment_amount"], [id^="hotel_payment_amount"]');

            paymentInputs.forEach(input => {
                input.addEventListener('input', function() {
                    const bookingId = this.getAttribute('data-booking-id');
                    const remaining = parseFloat(this.getAttribute('data-remaining'));
                    const currency = this.getAttribute('data-currency');
                    const paymentAmount = parseFloat(this.value) || 0;

                    // Calculate new remaining
                    const newRemaining = remaining - paymentAmount;

                    // Update the new remaining field
                    const newRemainingField = document.getElementById('new_remaining' +
                        bookingId) || document.getElementById('new_hotel_remaining' + bookingId);
                    if (newRemainingField) {
                        newRemainingField.value = newRemaining.toFixed(0) + ' ' + currency;

                        // Add visual feedback
                        if (paymentAmount > remaining) {
                            this.classList.add('is-invalid');
                            newRemainingField.classList.add('text-danger');
                        } else {
                            this.classList.remove('is-invalid');
                            newRemainingField.classList.remove('text-danger');
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mohamed Ayman\Herd\hotels\resources\views/admin/pages/dashboard.blade.php ENDPATH**/ ?>