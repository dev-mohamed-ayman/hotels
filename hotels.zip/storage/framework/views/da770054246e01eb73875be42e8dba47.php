<?php $__env->startSection('title', __('Bookings')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo e(__('Bookings List')); ?></h5>
                    <div class="d-flex gap-2 align-items-center">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($totalFilteredBookings) && $totalFilteredBookings > 0): ?>
                            <span class="text-muted small me-2">
                                <?php echo e(__('Total')); ?>: <strong><?php echo e($totalFilteredBookings); ?></strong> <?php echo e(__('booking(s)')); ?>

                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export bookings')): ?>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                    <i class="ti tabler-file-download me-2"></i><?php echo e(__('Export PDF')); ?>

                                </button>
                                <ul class="dropdown-menu">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export Bank')): ?>
                                        <li>
                                            <a class="dropdown-item"
                                               href="<?php echo e(route('bookings.export.bank', request()->query())); ?>"
                                               target="_blank">
                                                <i class="ti tabler-building-bank me-2"></i><?php echo e(__('Bank Export')); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export Detailed')): ?>
                                        <li>
                                            <a class="dropdown-item"
                                               href="<?php echo e(route('bookings.export.detailed', request()->query())); ?>"
                                               target="_blank">
                                                <i class="ti tabler-file-text me-2"></i><?php echo e(__('Detailed Export')); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export Guest')): ?>
                                        <li>
                                            <a class="dropdown-item"
                                               href="<?php echo e(route('bookings.export.guest', request()->query())); ?>"
                                               target="_blank">
                                                <i class="ti tabler-user me-2"></i><?php echo e(__('Guest Export')); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export Net Rate')): ?>
                                        <li>
                                            <a class="dropdown-item"
                                               href="<?php echo e(route('bookings.export.netrate', request()->query())); ?>"
                                               target="_blank">
                                                <i class="ti tabler-currency-dollar me-2"></i><?php echo e(__('Net Rate Export')); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create bookings')): ?>
                            <a href="<?php echo e(route('bookings.create')); ?>" class="btn btn-primary">
                                <i class="ti tabler-plus me-2"></i><?php echo e(__('Add Booking')); ?>

                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Filters Section -->
                    <div class="mb-3">
                        <div class="accordion" id="filterAccordion">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="filterHeading">
                                    <button
                                        class="accordion-button <?php echo e(request()->hasAny(['hotel_id', 'customer_id', 'payment_status', 'check_in_from', 'check_in_to', 'check_out_from', 'check_out_to', 'currency_id', 'search']) ? '' : 'collapsed'); ?>"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#filterCollapse">
                                        <i class="ti tabler-filter me-2"></i>
                                        <?php echo e(__('Filter Bookings')); ?>

                                        <?php
                                            $activeFilters = 0;
                                            if (request('hotel_id')) {
                                                $activeFilters++;
                                            }
                                            if (request('customer_id')) {
                                                $activeFilters++;
                                            }
                                            if (request('payment_status')) {
                                                $activeFilters++;
                                            }
                                            if (request('check_in_from') || request('check_in_to')) {
                                                $activeFilters++;
                                            }
                                            if (request('check_out_from') || request('check_out_to')) {
                                                $activeFilters++;
                                            }
                                            if (request('currency_id')) {
                                                $activeFilters++;
                                            }
                                            if (request('search')) {
                                                $activeFilters++;
                                            }
                                        ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeFilters > 0): ?>
                                            <span class="badge bg-primary ms-2"><?php echo e($activeFilters); ?></span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </button>
                                </h2>
                                <div id="filterCollapse"
                                     class="accordion-collapse collapse <?php echo e(request()->hasAny(['hotel_id', 'customer_id', 'payment_status', 'check_in_from', 'check_in_to', 'check_out_from', 'check_out_to', 'currency_id', 'search']) ? 'show' : ''); ?>"
                                     data-bs-parent="#filterAccordion">
                                    <div class="accordion-body">
                                        <form method="GET" action="<?php echo e(route('bookings.index')); ?>" id="filterForm">
                                            <div class="row g-3">
                                                <!-- Search -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Search by Code')); ?></label>
                                                    <input type="text" name="search" class="form-control"
                                                           value="<?php echo e(request('search')); ?>"
                                                           placeholder="<?php echo e(__('Enter booking code')); ?>">
                                                </div>

                                                <!-- Hotel Filter -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Hotel')); ?></label>
                                                    <select name="hotel_id" class="form-select select2-filter">
                                                        <option value=""><?php echo e(__('All')); ?></option>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($hotel->id); ?>"
                                                                <?php echo e(request('hotel_id') == $hotel->id ? 'selected' : ''); ?>>
                                                                <?php echo e($hotel->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    </select>
                                                </div>

                                                <!-- Customer Filter -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Customer')); ?></label>
                                                    <select name="customer_id" class="form-select select2-filter">
                                                        <option value=""><?php echo e(__('All')); ?></option>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($customer->id); ?>"
                                                                <?php echo e(request('customer_id') == $customer->id ? 'selected' : ''); ?>>
                                                                <?php echo e($customer->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    </select>
                                                </div>

                                                <!-- Payment Status Filter -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Payment Status')); ?></label>
                                                    <select name="payment_status" class="form-select">
                                                        <option value=""><?php echo e(__('All')); ?></option>
                                                        <option value="paid"
                                                            <?php echo e(request('payment_status') == 'paid' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Paid')); ?>

                                                        </option>
                                                        <option value="unpaid"
                                                            <?php echo e(request('payment_status') == 'unpaid' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Unpaid')); ?>

                                                        </option>
                                                        <option value="partial"
                                                            <?php echo e(request('payment_status') == 'partial' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Partial Payment')); ?>

                                                        </option>
                                                    </select>
                                                </div>

                                                <!-- Check-in From -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Check In')); ?> -
                                                        <?php echo e(__('From Date')); ?></label>
                                                    <input type="date" name="check_in_from" class="form-control"
                                                           value="<?php echo e(request('check_in_from')); ?>">
                                                </div>

                                                <!-- Check-in To -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Check In')); ?> -
                                                        <?php echo e(__('To Date')); ?></label>
                                                    <input type="date" name="check_in_to" class="form-control"
                                                           value="<?php echo e(request('check_in_to')); ?>">
                                                </div>

                                                <!-- Check-out From -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Check Out')); ?> -
                                                        <?php echo e(__('From Date')); ?></label>
                                                    <input type="date" name="check_out_from" class="form-control"
                                                           value="<?php echo e(request('check_out_from')); ?>">
                                                </div>

                                                <!-- Check-out To -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Check Out')); ?> -
                                                        <?php echo e(__('To Date')); ?></label>
                                                    <input type="date" name="check_out_to" class="form-control"
                                                           value="<?php echo e(request('check_out_to')); ?>">
                                                </div>

                                                <!-- Currency Filter -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Currency')); ?></label>
                                                    <select name="currency_id" class="form-select">
                                                        <option value=""><?php echo e(__('All')); ?></option>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($currency->id); ?>"
                                                                <?php echo e(request('currency_id') == $currency->id ? 'selected' : ''); ?>>
                                                                <?php echo e($currency->code); ?> - <?php echo e($currency->symbol); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    </select>
                                                </div>

                                                <!-- Sort By -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Sort By')); ?></label>
                                                    <select name="sort_by" class="form-select">
                                                        <option value="created_at"
                                                            <?php echo e(request('sort_by') == 'created_at' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Created At')); ?></option>
                                                        <option value="code"
                                                            <?php echo e(request('sort_by') == 'code' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Code')); ?></option>
                                                        <option value="check_in"
                                                            <?php echo e(request('sort_by') == 'check_in' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Check In')); ?></option>
                                                        <option value="check_out"
                                                            <?php echo e(request('sort_by') == 'check_out' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Check Out')); ?></option>
                                                        <option value="total_amount"
                                                            <?php echo e(request('sort_by') == 'total_amount' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Total Amount')); ?></option>
                                                        <option value="paid_amount"
                                                            <?php echo e(request('sort_by') == 'paid_amount' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Paid Amount')); ?></option>
                                                        <option value="status"
                                                            <?php echo e(request('sort_by') == 'status' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Status')); ?></option>
                                                        <option value="updated_at"
                                                            <?php echo e(request('sort_by') == 'updated_at' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Updated At')); ?></option>
                                                    </select>
                                                </div>

                                                <!-- Sort Order -->
                                                <div class="col-md-3">
                                                    <label class="form-label"><?php echo e(__('Sort Order')); ?></label>
                                                    <select name="sort_order" class="form-select">
                                                        <option value="desc"
                                                            <?php echo e(request('sort_order') == 'desc' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Descending')); ?></option>
                                                        <option value="asc"
                                                            <?php echo e(request('sort_order') == 'asc' ? 'selected' : ''); ?>>
                                                            <?php echo e(__('Ascending')); ?></option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="mt-3 d-flex gap-2">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="ti tabler-search me-2"></i><?php echo e(__('Apply Filters')); ?>

                                                </button>
                                                <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-secondary">
                                                    <i class="ti tabler-x me-2"></i><?php echo e(__('Clear All Filters')); ?>

                                                </a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Active Filters Display -->
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->hasAny([
                            'hotel_id',
                            'customer_id',
                            'payment_status',
                            'check_in_from',
                            'check_in_to',
                            'check_out_from',
                            'check_out_to',
                            'currency_id',
                            'search',
                            'sort_by',
                        ])): ?>
                        <div class="mb-3">
                            <strong><?php echo e(__('Active Filters')); ?>:</strong>
                            <div class="d-flex flex-wrap gap-2 mt-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('search')): ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Search')); ?>: <?php echo e(request('search')); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['search' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('hotel_id')): ?>
                                    <?php
                                        $selectedHotel = $hotels->firstWhere('id', request('hotel_id'));
                                    ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Hotel')); ?>: <?php echo e($selectedHotel?->name); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['hotel_id' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('customer_id')): ?>
                                    <?php
                                        $selectedCustomer = $customers->firstWhere('id', request('customer_id'));
                                    ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Customer')); ?>: <?php echo e($selectedCustomer?->name); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['customer_id' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('payment_status')): ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Payment Status')); ?>: <?php echo e(__(ucfirst(request('payment_status')))); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['payment_status' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('check_in_from') || request('check_in_to')): ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Check In')); ?>:
                                        <?php echo e(request('check_in_from') ? request('check_in_from') : '...'); ?>

                                        →
                                        <?php echo e(request('check_in_to') ? request('check_in_to') : '...'); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['check_in_from' => null, 'check_in_to' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('check_out_from') || request('check_out_to')): ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Check Out')); ?>:
                                        <?php echo e(request('check_out_from') ? request('check_out_from') : '...'); ?>

                                        →
                                        <?php echo e(request('check_out_to') ? request('check_out_to') : '...'); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['check_out_from' => null, 'check_out_to' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('currency_id')): ?>
                                    <?php
                                        $selectedCurrency = $currencies->firstWhere('id', request('currency_id'));
                                    ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Currency')); ?>: <?php echo e($selectedCurrency?->code); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['currency_id' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('sort_by')): ?>
                                    <span class="badge bg-label-primary">
                                        <?php echo e(__('Sort By')); ?>:
                                        <?php echo e(__(ucfirst(str_replace('_', ' ', request('sort_by'))))); ?>

                                        (<?php echo e(request('sort_order') == 'asc' ? __('Ascending') : __('Descending')); ?>)
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['sort_by' => null, 'sort_order' => null])); ?>"
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <!-- Per Page Selector -->
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center gap-2">
                            <label for="per_page" class="form-label mb-0"><?php echo e(__('Show')); ?>:</label>
                            <select name="per_page" id="per_page" class="form-select form-select-sm"
                                    style="width: auto;">
                                <option value="10" <?php echo e(request('per_page', 10) == 10 ? 'selected' : ''); ?>>10</option>
                                <option value="25" <?php echo e(request('per_page', 10) == 25 ? 'selected' : ''); ?>>25</option>
                                <option value="50" <?php echo e(request('per_page', 10) == 50 ? 'selected' : ''); ?>>50</option>
                                <option value="100" <?php echo e(request('per_page', 10) == 100 ? 'selected' : ''); ?>>100
                                </option>
                            </select>
                            <span class="text-muted small"><?php echo e(__('entries')); ?></span>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover text-center table-sm" style="font-size: 0.875rem;">
                            <thead>
                            <tr>
                                <th class="text-nowrap"><?php echo e(__('Code')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Hotel')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Rooms')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Check In')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Check Out')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Nights')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Total Net')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Paid Net')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Remaining Net')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Option Date')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Status')); ?></th>
                                <th class="text-nowrap"><?php echo e(__('Actions')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-nowrap py-2"><strong><?php echo e($booking->code); ?></strong></td>
                                    <td class="text-nowrap py-2"><?php echo e($booking->hotel->name); ?></td>
                                    <td class="py-2" style="width: 130px;">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->rooms && $booking->rooms->count() > 0): ?>
                                            <?php
                                                $roomTypes = ['SGL' => 0, 'DBL' => 0, 'TPL' => 0, 'QUD' => 0];
                                                $totalRooms = 0;
                                                foreach ($booking->rooms as $room) {
                                                    $roomTypes[$room->room_type] += $room->room_count;
                                                    $totalRooms += $room->room_count;
                                                }
                                            ?>
                                            <div class="text-start" style="line-height: 1.4;">
                                                <div class="mb-1">
                                                    <strong class="text-primary"><?php echo e($totalRooms); ?></strong>
                                                    <small
                                                        class="text-muted"><?php echo e($totalRooms == 1 ? __('Room') : __('Rooms')); ?></small>
                                                </div>
                                                <div class="d-flex flex-wrap gap-1">
                                                    <?php $__currentLoopData = ['SGL', 'DBL', 'TPL', 'QUD']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($roomTypes[$type] > 0): ?>
                                                            <span class="badge bg-label-info"
                                                                  style="font-size: 0.7rem; padding: 0.15rem 0.35rem; line-height: 1.2;">
                                                                    <?php echo e($roomTypes[$type]); ?>

                                                                    <strong><?php echo e($type); ?></strong>
                                                                </span>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td class="text-nowrap py-2"><?php echo e($booking->check_in->format('d-m-Y')); ?></td>
                                    <td class="text-nowrap py-2"><?php echo e($booking->check_out->format('d-m-Y')); ?></td>
                                    <td class="text-nowrap py-2"><?php echo e($booking->nights); ?></td>
                                    <td class="text-nowrap py-2">
                                        <?php echo e($booking->net_amount == 0 ? '' : $booking->currency->symbol . ' ' . number_format($booking->net_amount, 0)); ?>

                                    </td>
                                    <td class="text-nowrap py-2">
                                            <span class="fw-semibold text-success">
                                                <?php echo e($booking->hotel_paid_amount == 0 ? '' : $booking->currency->symbol . ' ' . number_format($booking->hotel_paid_amount, 0)); ?>

                                            </span>
                                    </td>
                                    <td class="text-nowrap py-2">
                                        <?php
                                            $remaining = $booking->net_amount - $booking->hotel_paid_amount;
                                        ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($remaining > 0): ?>
                                            <span class="badge bg-label-danger" style="font-size: 0.75rem;">
                                                    <i class="ti tabler-alert-circle me-1"></i>
                                                    <?php echo e($booking->currency->symbol); ?> <?php echo e(number_format($remaining, 0)); ?>

                                                </span>
                                        <?php elseif($booking->net_amount > 0): ?>
                                            <span class="badge bg-label-success" style="font-size: 0.75rem;">
                                                    <i class="ti tabler-check me-1"></i>
                                                    <?php echo e(__('Paid')); ?>

                                                </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>

                                    <td class="py-2">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->option_date): ?>
                                            <div class="d-flex flex-column align-items-center gap-1">
                                                <div class="d-flex align-items-center gap-1">
                                                    <i class="ti tabler-calendar-event text-primary"
                                                       style="font-size: 0.9rem;"></i>
                                                    <span
                                                        class="fw-semibold text-primary text-nowrap"><?php echo e($booking->option_date->format('d-m-Y')); ?></span>
                                                </div>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($remaining <= 0): ?>
                                                <?php else: ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->option_date->isPast()): ?>
                                                        <span class="badge bg-label-warning"
                                                              style="font-size: 0.65rem;"><?php echo e(__('Past')); ?></span>
                                                    <?php elseif($booking->option_date->isToday()): ?>
                                                        <span class="badge bg-label-info"
                                                              style="font-size: 0.65rem;"><?php echo e(__('Today')); ?></span>
                                                    <?php else: ?>
                                                        <span class="badge bg-label-success"
                                                              style="font-size: 0.65rem;"><?php echo e(__('Upcoming')); ?></span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td class="text-nowrap py-2">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->hotel_paid_amount == 0): ?>
                                            <span class="badge bg-danger" title="<?php echo e(__('Unpaid')); ?>"
                                                  style="font-size: 0.75rem;">
                                                    <i class="ti tabler-x"></i>
                                                </span>
                                        <?php elseif($booking->hotel_paid_amount >= $booking->net_amount && $booking->net_amount > 0): ?>
                                            <span class="badge bg-success" title="<?php echo e(__('Paid')); ?>"
                                                  style="font-size: 0.75rem;">
                                                    <i class="ti tabler-check"></i>
                                                </span>
                                        <?php elseif($booking->net_amount > 0): ?>
                                            <span class="badge bg-warning" title="<?php echo e(__('Partial Payment')); ?>"
                                                  style="font-size: 0.75rem;">
                                                    <i class="ti tabler-question-mark"></i>
                                                </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td class="text-nowrap">
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-icon btn-secondary" type="button"
                                                    id="actionsDropdown<?php echo e($booking->id); ?>" data-bs-toggle="dropdown"
                                                    aria-expanded="false" style="padding: 0.25rem 0.5rem;">
                                                <i class="ti tabler-dots-vertical" style="font-size: 0.9rem;"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end"
                                                aria-labelledby="actionsDropdown<?php echo e($booking->id); ?>">
                                                <li>
                                                    <a class="dropdown-item"
                                                       href="<?php echo e(route('bookings.show', $booking)); ?>">
                                                        <i class="ti tabler-eye me-2"></i><?php echo e(__('View Details')); ?>

                                                    </a>
                                                </li>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit bookings')): ?>
                                                    <li>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('bookings.edit', $booking)); ?>">
                                                            <i class="ti tabler-edit me-2"></i><?php echo e(__('Edit')); ?>

                                                        </a>
                                                    </li>
                                                    
                                                    <li>
                                                        <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                           data-bs-target="#hotelPaymentModal<?php echo e($booking->id); ?>">
                                                            <i
                                                                class="ti tabler-building me-2"></i><?php echo e(__('Update Hotel Payment')); ?>

                                                        </a>
                                                    </li>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete bookings')): ?>
                                                    <li>
                                                        <hr class="dropdown-divider">
                                                    </li>
                                                    <li>
                                                        <form action="<?php echo e(route('bookings.destroy', $booking)); ?>"
                                                              method="POST"
                                                              onsubmit="return confirm('<?php echo e(__('Are you sure you want to delete this booking?')); ?>')">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                    class="dropdown-item text-danger w-100 text-start">
                                                                <i
                                                                    class="ti tabler-trash me-2"></i><?php echo e(__('Delete')); ?>

                                                            </button>
                                                        </form>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Payment Update Modal -->
                                <div class="modal fade" id="paymentModal<?php echo e($booking->id); ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title"><?php echo e(__('Update Payment')); ?> -
                                                    <?php echo e($booking->code); ?></h5>
                                                <button type="button" class="btn-close"
                                                        data-bs-dismiss="modal"></button>
                                            </div>
                                            <form action="<?php echo e(route('bookings.update-payment', $booking)); ?>"
                                                  method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label"><?php echo e(__('Total Amount')); ?></label>
                                                        <input type="text" class="form-control"
                                                               value="<?php echo e($booking->total_amount == 0 ? '' : number_format($booking->total_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label
                                                            class="form-label"><?php echo e(__('Current Paid Amount')); ?></label>
                                                        <input type="text" class="form-control"
                                                               value="<?php echo e($booking->paid_amount == 0 ? '' : number_format($booking->paid_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                    <div class="mb-3">
                                                        <?php
                                                            $remaining =
                                                                $booking->total_amount - $booking->paid_amount;
                                                        ?>
                                                        <label
                                                            class="form-label"><?php echo e(__('Remaining Amount')); ?></label>
                                                        <input type="text" class="form-control"
                                                               id="remaining<?php echo e($booking->id); ?>"
                                                               value="<?php echo e($remaining == 0 ? '' : number_format($remaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                               for="payment_amount<?php echo e($booking->id); ?>"><?php echo e(__('Payment Amount')); ?>

                                                            *</label>
                                                        <div class="input-group">
                                                            <input type="number" step="0.01" class="form-control"
                                                                   id="payment_amount<?php echo e($booking->id); ?>"
                                                                   name="payment_amount" min="0.01"
                                                                   max="<?php echo e($remaining); ?>"
                                                                   data-remaining="<?php echo e($remaining); ?>"
                                                                   data-currency="<?php echo e($booking->currency->symbol); ?>"
                                                                   data-booking-id="<?php echo e($booking->id); ?>"
                                                                   placeholder="<?php echo e(__('Enter amount to pay')); ?>"
                                                                   required>
                                                            <span
                                                                class="input-group-text"><?php echo e($booking->currency->symbol); ?></span>
                                                        </div>
                                                        <small class="text-muted"><?php echo e(__('Maximum')); ?>:
                                                            <?php echo e(number_format($remaining, 0)); ?>

                                                            <?php echo e($booking->currency->symbol); ?></small>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label
                                                            class="form-label"><?php echo e(__('New Remaining Amount')); ?></label>
                                                        <input type="text" class="form-control"
                                                               id="new_remaining<?php echo e($booking->id); ?>"
                                                               value="<?php echo e(number_format($remaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                    <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Hotel Payment Update Modal -->
                                <div class="modal fade" id="hotelPaymentModal<?php echo e($booking->id); ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title"><?php echo e(__('Update Hotel Payment')); ?> -
                                                    <?php echo e($booking->code); ?></h5>
                                                <button type="button" class="btn-close"
                                                        data-bs-dismiss="modal"></button>
                                            </div>
                                            <form action="<?php echo e(route('bookings.update-hotel-payment', $booking)); ?>"
                                                  method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label
                                                            class="form-label"><?php echo e(__('Total Net Amount')); ?></label>
                                                        <input type="text" class="form-control"
                                                               value="<?php echo e($booking->net_amount == 0 ? '' : number_format($booking->net_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label"><?php echo e(__('Paid to Hotel')); ?></label>
                                                        <input type="text" class="form-control"
                                                               value="<?php echo e($booking->hotel_paid_amount == 0 ? '' : number_format($booking->hotel_paid_amount, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                    <div class="mb-3">
                                                        <?php
                                                            $hotelRemaining =
                                                                $booking->net_amount - $booking->hotel_paid_amount;
                                                        ?>
                                                        <label
                                                            class="form-label"><?php echo e(__('Remaining Amount')); ?></label>
                                                        <input type="text" class="form-control"
                                                               id="hotel_remaining<?php echo e($booking->id); ?>"
                                                               value="<?php echo e($hotelRemaining == 0 ? '' : number_format($hotelRemaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                               for="hotel_payment_amount<?php echo e($booking->id); ?>"><?php echo e(__('Payment Amount')); ?>

                                                            *</label>
                                                        <div class="input-group">
                                                            <input type="number" step="0.01" class="form-control"
                                                                   id="hotel_payment_amount<?php echo e($booking->id); ?>"
                                                                   name="payment_amount" min="0.01"
                                                                   max="<?php echo e(max($hotelRemaining, 0.01)); ?>"
                                                                   data-remaining="<?php echo e($hotelRemaining); ?>"
                                                                   data-currency="<?php echo e($booking->currency->symbol); ?>"
                                                                   data-booking-id="<?php echo e($booking->id); ?>"
                                                                   placeholder="<?php echo e(__('Enter amount to pay')); ?>"
                                                                   required>
                                                            <span
                                                                class="input-group-text"><?php echo e($booking->currency->symbol); ?></span>
                                                        </div>
                                                        <small class="text-muted"><?php echo e(__('Maximum')); ?>:
                                                            <?php echo e(number_format(max($hotelRemaining, 0), 0)); ?>

                                                            <?php echo e($booking->currency->symbol); ?></small>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label
                                                            class="form-label"><?php echo e(__('New Remaining Amount')); ?></label>
                                                        <input type="text" class="form-control"
                                                               id="new_hotel_remaining<?php echo e($booking->id); ?>"
                                                               value="<?php echo e(number_format($hotelRemaining, 0)); ?> <?php echo e($booking->currency->symbol); ?>"
                                                               readonly>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                    <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10" class="text-center py-5">
                                        <div class="d-flex flex-column align-items-center">
                                            <i class="ti tabler-inbox" style="font-size: 3rem; color: #cbd5e0;"></i>
                                            <p class="mt-3 text-muted"><?php echo e(__('No bookings found')); ?></p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-3">
                        <?php echo e($bookings->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                // Initialize Select2 for filter dropdowns
                if (typeof $.fn.select2 !== 'undefined') {
                    $('.select2-filter').select2({
                        theme: 'bootstrap-5',
                        placeholder: '<?php echo e(__('Select')); ?>',
                        allowClear: true,
                        width: '100%'
                    });
                }

                // Get all payment amount inputs
                const paymentInputs = document.querySelectorAll('[id^="payment_amount"], [id^="hotel_payment_amount"]');

                paymentInputs.forEach(input => {
                    input.addEventListener('input', function () {
                        const bookingId = this.getAttribute('data-booking-id');
                        const remaining = parseFloat(this.getAttribute('data-remaining'));
                        const currency = this.getAttribute('data-currency');
                        const paymentAmount = parseFloat(this.value) || 0;

                        // Calculate new remaining
                        const newRemaining = remaining - paymentAmount;

                        const newRemaining = remaining - paymentAmount;

                        // Update the new remaining field
                        const newRemainingField = document.getElementById('new_remaining' +
                            bookingId) || document.getElementById('new_hotel_remaining' + bookingId);
                        if (newRemainingField) {
                            newRemainingField.value = newRemaining.toFixed(2) + ' ' + currency;

                            // Add visual feedback
                            if (paymentAmount > remaining) {
                                this.classList.add('is-invalid');
                                newRemainingField.classList.add('text-danger');
                            } else {
                                this.classList.remove('is-invalid');
                                newRemainingField.classList.remove('text-danger');
                            }
                        }
                    });
                });
            });

            // Handle per page change
            const perPageSelect = document.getElementById('per_page');
            if (perPageSelect) {
                perPageSelect.addEventListener('change', function () {
                    const url = new URL(window.location.href);
                    url.searchParams.set('per_page', this.value);
                    url.searchParams.set('page', '1'); // Reset to first page
                    window.location.href = url.toString();
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mohamed Ayman\Herd\hotels\resources\views/admin/pages/bookings/index.blade.php ENDPATH**/ ?>