<?php $__env->startSection('title', __('Booking Details')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Booking Information Card -->
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-1 fw-bold"><?php echo e(__('Booking Details')); ?></h4>
                        <p class="mb-0 text-muted small"><?php echo e(__('Code')); ?>: <span
                                class="fw-semibold text-primary"><?php echo e($booking->code); ?></span></p>
                    </div>
                    <div class="d-flex gap-2 flex-wrap">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export bookings')): ?>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <i class="ti tabler-file-download me-2"></i><?php echo e(__('Download PDF')); ?>

                                </button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('bookings.pdf.bank', $booking->id)); ?>"
                                            target="_blank">
                                            <i class="ti tabler-building-bank me-2"></i><?php echo e(__('Bank Export')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('bookings.pdf.detailed', $booking->id)); ?>"
                                            target="_blank">
                                            <i class="ti tabler-file-text me-2"></i><?php echo e(__('Detailed Export')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('bookings.pdf.guest', $booking->id)); ?>"
                                            target="_blank">
                                            <i class="ti tabler-user me-2"></i><?php echo e(__('Guest Export')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('bookings.pdf.netrate', $booking->id)); ?>"
                                            target="_blank">
                                            <i class="ti tabler-currency-dollar me-2"></i><?php echo e(__('Net Rate Export')); ?>

                                        </a>
                                    </li>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit bookings')): ?>
                            <a href="<?php echo e(route('bookings.edit', $booking->id)); ?>" class="btn btn-primary btn-sm">
                                <i class="ti tabler-edit me-2"></i><?php echo e(__('Edit')); ?>

                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-secondary btn-sm">
                            <i class="ti tabler-arrow-left me-2"></i><?php echo e(__('Back')); ?>

                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-4">
                        <!-- Customer & Hotel Info -->
                        <div class="col-lg-4 col-md-6">
                            <div class="card border shadow-none h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="avatar avatar-md me-3">
                                            <span class="avatar-initial rounded bg-label-primary">
                                                <i class="ti tabler-user ti-md"></i>
                                            </span>
                                        </div>
                                        <div>
                                            <h6 class="mb-0"><?php echo e(__('Customer')); ?></h6>
                                            <small class="text-muted"><?php echo e(__('Customer Information')); ?></small>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <a href="<?php echo e(route('customers.show', $booking->customer_id)); ?>"
                                            class="text-decoration-none fw-semibold">
                                            <?php echo e($booking->customer->name); ?>

                                        </a>
                                    </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->customer->phone_1): ?>
                                        <div class="text-muted small">
                                            <i class="ti tabler-phone me-1"></i><?php echo e($booking->customer->phone_1); ?>

                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->customer->email): ?>
                                        <div class="text-muted small">
                                            <i class="ti tabler-mail me-1"></i><?php echo e($booking->customer->email); ?>

                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="card border shadow-none h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="avatar avatar-md me-3">
                                            <span class="avatar-initial rounded bg-label-info">
                                                <i class="ti tabler-building ti-md"></i>
                                            </span>
                                        </div>
                                        <div>
                                            <h6 class="mb-0"><?php echo e(__('Hotel')); ?></h6>
                                            <small class="text-muted"><?php echo e(__('Hotel Information')); ?></small>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <a href="<?php echo e(route('hotels.show', $booking->hotel_id)); ?>"
                                            class="text-decoration-none fw-semibold">
                                            <?php echo e($booking->hotel->name); ?>

                                        </a>
                                    </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->hotel->address): ?>
                                        <div class="text-muted small">
                                            <i
                                                class="ti tabler-map-pin me-1"></i><?php echo e(Str::limit($booking->hotel->address, 50)); ?>

                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Booking Dates -->
                        <div class="col-lg-4 col-md-6">
                            <div class="card border shadow-none h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="avatar avatar-md me-3">
                                            <span class="avatar-initial rounded bg-label-success">
                                                <i class="ti tabler-calendar ti-md"></i>
                                            </span>
                                        </div>
                                        <div>
                                            <h6 class="mb-0"><?php echo e(__('Booking Dates')); ?></h6>
                                            <small class="text-muted"><?php echo e(__('Check In/Out')); ?></small>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-muted small"><?php echo e(__('Check In')); ?>:</span>
                                            <span class="fw-semibold"><?php echo e($booking->check_in->format('d-m-Y')); ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-muted small"><?php echo e(__('Check Out')); ?>:</span>
                                            <span class="fw-semibold"><?php echo e($booking->check_out->format('d-m-Y')); ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="text-muted small"><?php echo e(__('Nights')); ?>:</span>
                                            <span class="badge bg-label-primary"><?php echo e($booking->nights); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Financial Info -->
                        <div class="col-lg-6 col-md-6">
                            <div class="card border shadow-none">
                                <div class="card-header bg-label-primary">
                                    <h6 class="mb-0 text-primary">
                                        <i class="ti tabler-currency-dollar me-2"></i><?php echo e(__('Financial Information')); ?>

                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-6">
                                            <div class="mb-3">
                                                <label
                                                    class="form-label text-muted small mb-1"><?php echo e(__('Currency')); ?></label>
                                                <div>
                                                    <span
                                                        class="badge bg-label-primary fs-6"><?php echo e($booking->currency->symbol ?? '-'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="mb-3">
                                                <label
                                                    class="form-label text-muted small mb-1"><?php echo e(__('Status')); ?></label>
                                                <div>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->status == 'pending'): ?>
                                                        <span class="badge bg-label-warning"><?php echo e(__('Pending')); ?></span>
                                                    <?php elseif($booking->status == 'confirmed'): ?>
                                                        <span class="badge bg-label-success"><?php echo e(__('Confirmed')); ?></span>
                                                    <?php elseif($booking->status == 'cancelled'): ?>
                                                        <span class="badge bg-label-danger"><?php echo e(__('Cancelled')); ?></span>
                                                    <?php else: ?>
                                                        <span
                                                            class="badge bg-label-secondary"><?php echo e(__(ucfirst($booking->status))); ?></span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div
                                                class="d-flex justify-content-between align-items-center p-3 bg-label-success rounded mb-2">
                                                <div>
                                                    <span class="text-muted small d-block"><?php echo e(__('Total Amount')); ?></span>
                                                    <span
                                                        class="fw-bold fs-5 text-success"><?php echo e($booking->total_amount == 0 ? '' : number_format($booking->total_amount, 0)); ?>

                                                        <?php echo e($booking->currency->symbol ?? ''); ?></span>
                                                </div>
                                                <div class="avatar">
                                                    <span class="avatar-initial rounded bg-success">
                                                        <i class="ti tabler-currency-dollar"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div
                                                class="d-flex justify-content-between align-items-center p-2 bg-label-primary rounded">
                                                <span class="text-muted small"><?php echo e(__('Paid')); ?></span>
                                                <span
                                                    class="fw-semibold text-primary"><?php echo e($booking->paid_amount == 0 ? '' : number_format($booking->paid_amount, 0)); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div
                                                class="d-flex justify-content-between align-items-center p-2 bg-label-warning rounded">
                                                <span class="text-muted small"><?php echo e(__('Pending')); ?></span>
                                                <span
                                                    class="fw-semibold text-warning"><?php echo e($booking->total_amount - $booking->paid_amount == 0 ? '' : number_format($booking->total_amount - $booking->paid_amount, 0)); ?></span>
                                            </div>
                                        </div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->child_price > 0 || $booking->child_margin > 0): ?>
                                            <div class="col-6">
                                                <div class="mb-2">
                                                    <label
                                                        class="form-label text-muted small mb-1"><?php echo e(__('Child Net Rate')); ?></label>
                                                    <div class="fw-semibold">
                                                        <?php echo e($booking->child_price == 0 ? '' : number_format($booking->child_price, 0)); ?>

                                                        <?php echo e($booking->currency->symbol ?? ''); ?></div>
                                                </div>
                                            </div>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                <div class="col-6">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label text-muted small mb-1"><?php echo e(__('Child Margin')); ?></label>
                                                        <div class="fw-semibold">
                                                            <?php echo e($booking->child_margin == 0 ? '' : number_format($booking->child_margin, 0)); ?>

                                                            <?php echo e($booking->currency->symbol ?? ''); ?></div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->notes && ($booking->option_date || $booking->payment_date)): ?>
                                            <div class="col-12">
                                                <div class="mb-2">
                                                    <label
                                                        class="form-label text-muted small mb-1"><?php echo e(__('Option Date')); ?></label>
                                                    <div class="fw-semibold">
                                                        <?php echo e($booking->option_date ? $booking->option_date->format('d-m-Y') : ($booking->payment_date ? $booking->payment_date->format('d-m-Y') : '-')); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Hotel Financial Info -->
                        <div class="col-lg-6 col-md-6">
                            <div class="card border shadow-none">
                                <div class="card-header bg-label-secondary">
                                    <h6 class="mb-0 text-secondary">
                                        <i
                                            class="ti tabler-building-bank me-2"></i><?php echo e(__('Hotel Financial Information')); ?>

                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <div
                                                class="d-flex justify-content-between align-items-center p-3 bg-label-secondary rounded mb-2">
                                                <div>
                                                    <span
                                                        class="text-muted small d-block"><?php echo e(__('Total Net Amount')); ?></span>
                                                    <span
                                                        class="fw-bold fs-5 text-secondary"><?php echo e($booking->net_amount == 0 ? '' : number_format($booking->net_amount, 0)); ?>

                                                        <?php echo e($booking->currency->symbol ?? ''); ?></span>
                                                </div>
                                                <div class="avatar">
                                                    <span class="avatar-initial rounded bg-secondary">
                                                        <i class="ti tabler-building-bank"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div
                                                class="d-flex justify-content-between align-items-center p-2 bg-label-primary rounded">
                                                <span class="text-muted small"><?php echo e(__('Paid to Hotel')); ?></span>
                                                <span
                                                    class="fw-semibold text-primary"><?php echo e($booking->hotel_paid_amount == 0 ? '' : number_format($booking->hotel_paid_amount, 0)); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div
                                                class="d-flex justify-content-between align-items-center p-2 bg-label-warning rounded">
                                                <span class="text-muted small"><?php echo e(__('Pending')); ?></span>
                                                <span
                                                    class="fw-semibold text-warning"><?php echo e($booking->net_amount - $booking->hotel_paid_amount == 0 ? '' : number_format($booking->net_amount - $booking->hotel_paid_amount, 0)); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->notes): ?>
                            <!-- Notes -->
                            <div class="col-lg-6 col-md-6">
                                <div class="card border shadow-none h-100">
                                    <div class="card-header bg-label-info">
                                        <h6 class="mb-0 text-info">
                                            <i class="ti tabler-notes me-2"></i><?php echo e(__('Notes')); ?>

                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="p-3 bg-label-info rounded">
                                            <p class="mb-0"><?php echo e($booking->notes); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- Additional Details -->
                            <div class="col-lg-6 col-md-6">
                                <div class="card border shadow-none h-100">
                                    <div class="card-header bg-label-secondary">
                                        <h6 class="mb-0 text-secondary">
                                            <i class="ti tabler-info-circle me-2"></i><?php echo e(__('Additional Details')); ?>

                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->option_date || $booking->payment_date): ?>
                                            <div class="mb-3">
                                                <label
                                                    class="form-label text-muted small mb-1"><?php echo e(__('Option Date')); ?></label>
                                                <div class="fw-semibold">
                                                    <?php echo e($booking->option_date ? $booking->option_date->format('d-m-Y') : ($booking->payment_date ? $booking->payment_date->format('d-m-Y') : '-')); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <div class="mb-3">
                                            <label class="form-label text-muted small mb-1"><?php echo e(__('Created At')); ?></label>
                                            <div class="fw-semibold"><?php echo e(formatDateTime($booking->created_at)); ?></div>
                                        </div>
                                        <div>
                                            <label class="form-label text-muted small mb-1"><?php echo e(__('Updated At')); ?></label>
                                            <div class="fw-semibold"><?php echo e(formatDateTime($booking->updated_at)); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rooms Information -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->rooms->count() > 0): ?>
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo e(__('Rooms')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Room Type')); ?></th>
                                        <th><?php echo e(__('Category')); ?></th>
                                        <th><?php echo e(__('Room Count')); ?></th>
                                        <th><?php echo e(__('Net Rate')); ?></th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                            <th><?php echo e(__('Margin')); ?></th>
                                        <?php endif; ?>
                                        <th><?php echo e(__('Child Count')); ?></th>
                                        <th><?php echo e(__('Child Net Rate')); ?></th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                            <th><?php echo e(__('Child Margin')); ?></th>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                            <th><?php echo e(__('Subtotal')); ?></th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $booking->rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($room->room_type); ?></td>
                                            <td><?php echo e($room->category ?? '-'); ?></td>
                                            <td><?php echo e($room->room_count); ?></td>
                                            <td><?php echo e($room->price == 0 ? '' : number_format($room->price, 0)); ?></td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                <td><?php echo e($room->margin == 0 ? '' : number_format($room->margin, 0)); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($room->child_count == 0 ? '' : $room->child_count); ?></td>
                                            <td><?php echo e($room->child_price ? ($room->child_price == 0 ? '' : number_format($room->child_price, 0)) : '-'); ?>

                                            </td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                <td><?php echo e($room->child_margin ? ($room->child_margin == 0 ? '' : number_format($room->child_margin, 0)) : '-'); ?>

                                                </td>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                                <td>
                                                    <?php echo e(($room->price + $room->margin) * $room->room_count * $booking->nights == 0 ? '' : number_format(($room->price + $room->margin) * $room->room_count * $booking->nights, 0)); ?>

                                                    <?php echo e($booking->currency->symbol ?? ''); ?>

                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <!-- Adjustments (Additions & Discounts) -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->adjustments->count() > 0): ?>
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo e(__('Extras')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <!-- Additions -->
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->adjustments->where('type', 'addition')->count() > 0): ?>
                                <div class="col-md-6 mb-3">
                                    <h6 class="text-success mb-3"><?php echo e(__('Additions')); ?></h6>
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered">
                                            <thead>
                                                <tr>
                                                    <th><?php echo e(__('Description')); ?></th>
                                                    <th><?php echo e(__('Net Rate')); ?></th>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                                        <th><?php echo e(__('Guest Rate')); ?></th>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                        <th><?php echo e(__('Margin')); ?></th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $booking->adjustments->where('type', 'addition'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($addition->description); ?></td>
                                                        <td class="text-muted">
                                                            <?php echo e(($val = $addition->net_rate ?? ($addition->amount ?? 0)) == 0 ? '' : number_format($val, 0)); ?>

                                                            <?php echo e($booking->currency->symbol ?? ''); ?>

                                                        </td>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                                            <td class="text-success fw-semibold">
                                                                +<?php echo e(($val = $addition->guest_rate ?? ($addition->amount ?? 0)) == 0 ? '' : number_format($val, 0)); ?>

                                                                <?php echo e($booking->currency->symbol ?? ''); ?>

                                                            </td>
                                                        <?php endif; ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                            <td class="text-primary">
                                                                <?php echo e(($val = $addition->margin ?? ($addition->guest_rate ?? ($addition->amount ?? 0)) - ($addition->net_rate ?? 0)) == 0 ? '' : number_format($val, 0)); ?>

                                                                <?php echo e($booking->currency->symbol ?? ''); ?>

                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr class="fw-bold table-active border-top border-2 border-dark">
                                                    <td class="text-uppercase"><?php echo e(__('Total')); ?></td>
                                                    <td class="text-muted">
                                                        <?php echo e(($val = $booking->adjustments->where('type', 'addition')->sum('net_rate') ?: $booking->adjustments->where('type', 'addition')->sum('amount')) == 0 ? '' : number_format($val, 0)); ?>

                                                        <?php echo e($booking->currency->symbol ?? ''); ?>

                                                    </td>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                                        <td class="text-success">
                                                            +<?php echo e(($val = $booking->adjustments->where('type', 'addition')->sum('guest_rate') ?: $booking->adjustments->where('type', 'addition')->sum('amount')) == 0 ? '' : number_format($val, 0)); ?>

                                                            <?php echo e($booking->currency->symbol ?? ''); ?>

                                                        </td>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                        <td class="text-primary">
                                                            <?php echo e(($val = $booking->adjustments->where('type', 'addition')->sum('margin') ?: $booking->adjustments->where('type', 'addition')->sum('guest_rate') - $booking->adjustments->where('type', 'addition')->sum('net_rate')) == 0 ? '' : number_format($val, 0)); ?>

                                                            <?php echo e($booking->currency->symbol ?? ''); ?>

                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <!-- Discounts -->
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->adjustments->where('type', 'discount')->count() > 0): ?>
                                <div class="col-md-6 mb-3">
                                    <h6 class="text-danger mb-3"><?php echo e(__('Discounts')); ?></h6>
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered">
                                            <thead>
                                                <tr>
                                                    <th><?php echo e(__('Description')); ?></th>
                                                    <th><?php echo e(__('Net Rate')); ?></th>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                                        <th><?php echo e(__('Guest Rate')); ?></th>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                        <th><?php echo e(__('Margin')); ?></th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $booking->adjustments->where('type', 'discount'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($discount->description); ?></td>
                                                        <td class="text-muted">
                                                            <?php echo e(($val = $discount->net_rate ?? ($discount->amount ?? 0)) == 0 ? '' : number_format($val, 0)); ?>

                                                            <?php echo e($booking->currency->symbol ?? ''); ?>

                                                        </td>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                                            <td class="text-danger fw-semibold">
                                                                -<?php echo e(($val = $discount->guest_rate ?? ($discount->amount ?? 0)) == 0 ? '' : number_format($val, 0)); ?>

                                                                <?php echo e($booking->currency->symbol ?? ''); ?>

                                                            </td>
                                                        <?php endif; ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                            <td class="text-primary">
                                                                <?php echo e(($val = $discount->margin ?? ($discount->guest_rate ?? ($discount->amount ?? 0)) - ($discount->net_rate ?? 0)) == 0 ? '' : number_format($val, 0)); ?>

                                                                <?php echo e($booking->currency->symbol ?? ''); ?>

                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr class="fw-bold table-active border-top border-2 border-dark">
                                                    <td class="text-uppercase"><?php echo e(__('Total')); ?></td>
                                                    <td class="text-muted">
                                                        <?php echo e(($val = $booking->adjustments->where('type', 'discount')->sum('net_rate') ?: $booking->adjustments->where('type', 'discount')->sum('amount')) == 0 ? '' : number_format($val, 0)); ?>

                                                        <?php echo e($booking->currency->symbol ?? ''); ?>

                                                    </td>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking guest rates')): ?>
                                                        <td class="text-danger">
                                                            -<?php echo e(($val = $booking->adjustments->where('type', 'discount')->sum('guest_rate') ?: $booking->adjustments->where('type', 'discount')->sum('amount')) == 0 ? '' : number_format($val, 0)); ?>

                                                            <?php echo e($booking->currency->symbol ?? ''); ?>

                                                        </td>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view booking margins')): ?>
                                                        <td class="text-primary">
                                                            <?php echo e(($val = $booking->adjustments->where('type', 'discount')->sum('margin') ?: $booking->adjustments->where('type', 'discount')->sum('guest_rate') - $booking->adjustments->where('type', 'discount')->sum('net_rate')) == 0 ? '' : number_format($val, 0)); ?>

                                                            <?php echo e($booking->currency->symbol ?? ''); ?>

                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <!-- Summary Card -->
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><?php echo e(__('Summary')); ?></h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light">
                                <div class="card-body text-center">
                                    <h6 class="text-muted mb-2"><?php echo e(__('Total Amount')); ?></h6>
                                    <h4 class="mb-0 text-success">
                                        <?php echo e($booking->total_amount == 0 ? '' : number_format($booking->total_amount, 0)); ?><br>
                                        <small class="text-muted"><?php echo e($booking->currency->symbol ?? ''); ?></small>
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light">
                                <div class="card-body text-center">
                                    <h6 class="text-muted mb-2"><?php echo e(__('Paid Amount')); ?></h6>
                                    <h4 class="mb-0 text-primary">
                                        <?php echo e($booking->paid_amount == 0 ? '' : number_format($booking->paid_amount, 0)); ?><br>
                                        <small class="text-muted"><?php echo e($booking->currency->symbol ?? ''); ?></small>
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light">
                                <div class="card-body text-center">
                                    <h6 class="text-muted mb-2"><?php echo e(__('Pending Amount')); ?></h6>
                                    <h4 class="mb-0 text-warning">
                                        <?php echo e($booking->total_amount - $booking->paid_amount == 0 ? '' : number_format($booking->total_amount - $booking->paid_amount, 0)); ?><br>
                                        <small class="text-muted"><?php echo e($booking->currency->symbol ?? ''); ?></small>
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light">
                                <div class="card-body text-center">
                                    <h6 class="text-muted mb-2"><?php echo e(__('Created At')); ?></h6>
                                    <p class="mb-0"><?php echo e(formatDateTime($booking->created_at)); ?></p>
                                    <h6 class="text-muted mb-2 mt-3"><?php echo e(__('Updated At')); ?></h6>
                                    <p class="mb-0"><?php echo e(formatDateTime($booking->updated_at)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mohamed Ayman\Herd\hotels\resources\views/admin/pages/bookings/show.blade.php ENDPATH**/ ?>