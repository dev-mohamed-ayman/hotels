<nav class="layout-navbar container-xxl navbar-detached navbar navbar-expand-xl align-items-center bg-navbar-theme"
    id="layout-navbar">
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0   d-xl-none ">
        <a class="nav-item nav-link px-0 me-xl-6" href="javascript:void(0)">
            <i class="icon-base ti tabler-menu-2 icon-md"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center justify-content-end" id="navbar-collapse">

        <h4 class="m-0"><?php echo $__env->yieldContent('title'); ?></h4>

        <ul class="navbar-nav flex-row align-items-center ms-md-auto">
            <!-- Language -->
            <li class="nav-item dropdown-language dropdown me-2 me-xl-0">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <i class="icon-base ti tabler-language icon-22px text-heading"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a class="dropdown-item <?php echo e(app()->getLocale() == $localeCode ? 'active' : ''); ?>"
                                rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"
                                data-text-direction="<?php echo e($localeCode == 'ar' ? 'rtl' : 'ltr'); ?>">
                                <span><?php echo e($properties['native']); ?></span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </li>
            <!--/ Language -->

            <!-- Layout Toggle (Visual Only) -->
            <li class="nav-item dropdown me-2 me-xl-0">
                <a class="nav-link dropdown-toggle hide-arrow btn btn-icon btn-text-secondary rounded-pill"
                    href="javascript:void(0);" data-bs-toggle="dropdown" title="Sidebar Layout">
                    <i class="icon-base icon-22px text-heading" id="layout-icon"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <button type="button" class="dropdown-item align-items-center" data-layout-value="vertical">
                            <span><i class="icon-base ti tabler-layout-sidebar icon-22px me-3"></i>Vertical
                                Sidebar</span>
                        </button>
                    </li>
                    <li>
                        <button type="button" class="dropdown-item align-items-center" data-layout-value="horizontal">
                            <span><i class="icon-base ti tabler-layout-navbar icon-22px me-3"></i>Horizontal
                                Sidebar</span>
                        </button>
                    </li>
                </ul>
            </li>
            <!--/ Layout Toggle -->

            <!-- Style Switcher -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle hide-arrow btn btn-icon btn-text-secondary rounded-pill"
                    id="nav-theme" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <i class="icon-base ti tabler-sun icon-22px theme-icon-active text-heading"></i>
                    <span class="d-none ms-2" id="nav-theme-text"><?php echo e(__('Toggle theme')); ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="nav-theme-text">
                    <li>
                        <button type="button" class="dropdown-item align-items-center active"
                            data-bs-theme-value="light" aria-pressed="false">
                            <span><i class="icon-base ti tabler-sun icon-22px me-3"
                                    data-icon="sun"></i><?php echo e(__('Light')); ?></span>
                        </button>
                    </li>
                    <li>
                        <button type="button" class="dropdown-item align-items-center" data-bs-theme-value="dark"
                            aria-pressed="true">
                            <span><i class="icon-base ti tabler-moon-stars icon-22px me-3"
                                    data-icon="moon-stars"></i><?php echo e(__('Dark')); ?></span>
                        </button>
                    </li>
                    <li>
                        <button type="button" class="dropdown-item align-items-center" data-bs-theme-value="system"
                            aria-pressed="false">
                            <span><i class="icon-base ti tabler-device-desktop-analytics icon-22px me-3"
                                    data-icon="device-desktop-analytics"></i><?php echo e(__('System')); ?></span>
                        </button>
                    </li>
                </ul>
            </li>
            <!-- / Style Switcher-->

            <script>
                // Sidebar Layout Toggle (Cookie Only)
                document.addEventListener('DOMContentLoaded', function() {
                    const layoutButtons = document.querySelectorAll('[data-layout-value]');

                    // Helper function to get cookie value
                    function getCookie(name) {
                        const value = `; ${document.cookie}`;
                        const parts = value.split(`; ${name}=`);
                        if (parts.length === 2) return parts.pop().split(';').shift();
                        return null;
                    }

                    // Helper function to set cookie
                    function setCookie(name, value) {
                        document.cookie = `${name}=${value}; path=/; max-age=31536000; SameSite=Lax`;
                    }

                    const savedLayout = getCookie('sidebarLayout') || 'vertical';
                    const layoutIcon = document.getElementById('layout-icon');

                    // Update main icon based on saved layout
                    if (layoutIcon) {
                        if (savedLayout === 'horizontal') {
                            layoutIcon.className = 'icon-base ti tabler-layout-navbar icon-22px text-heading';
                        } else {
                            layoutIcon.className = 'icon-base ti tabler-layout-sidebar icon-22px text-heading';
                        }
                    }

                    // Set active class based on saved preference
                    layoutButtons.forEach(button => {
                        if (button.getAttribute('data-layout-value') === savedLayout) {
                            button.classList.add('active');
                        } else {
                            button.classList.remove('active');
                        }
                    });

                    // Handle click events
                    layoutButtons.forEach(button => {
                        button.addEventListener('click', function() {
                            const layout = this.getAttribute('data-layout-value');

                            // Save to Cookie only
                            setCookie('sidebarLayout', layout);

                            // Reload page to apply changes
                            window.location.reload();
                        });
                    });
                });
            </script>



            <!-- User -->
            <li class="nav-item navbar-dropdown dropdown-user dropdown ms-3">
                <a class="nav-link dropdown-toggle hide-arrow p-0" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                        <img src="<?php echo e(auth()->user()->avatar ? asset(auth()->user()->avatar) : asset('assets/img/avatars/1.png')); ?>"
                            alt class="rounded-circle" />
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item mt-0" href="<?php echo e(route('profile.index')); ?>">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo e(auth()->user()->avatar ? asset(auth()->user()->avatar) : asset('assets/img/avatars/1.png')); ?>"
                                            alt class="rounded-circle" />
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-0"><?php echo e(auth()->user()->name); ?></h6>
                                    <small class="text-body-secondary"><?php echo e(auth()->user()->email); ?></small>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider my-1 mx-n2"></div>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('profile.index')); ?>">
                            <i class="icon-base ti tabler-user me-3 icon-md"></i><span class="align-middle">My
                                Profile</span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('profile.index')); ?>">
                            <i class="icon-base ti tabler-settings me-3 icon-md"></i><span
                                class="align-middle"><?php echo e(__('Settings')); ?></span>
                        </a>
                    </li>

                    <li>
                        <div class="d-grid px-2 pt-2 pb-1">
                            <a class="btn btn-sm btn-danger d-flex" href="<?php echo e(route('logout')); ?>">
                                <small class="align-middle"><?php echo e(__('Logout')); ?></small>
                                <i class="icon-base ti tabler-logout ms-2 icon-14px"></i>
                            </a>
                        </div>
                    </li>
                </ul>
            </li>
            <!--/ User -->
        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\Mohamed Ayman\Herd\hotels\resources\views/admin/layouts/vertical/navbar.blade.php ENDPATH**/ ?>