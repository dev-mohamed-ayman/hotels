<?php
    $recentActivities = \Spatie\Activitylog\Models\Activity::with(['causer'])
        ->latest()
        ->take(5)
        ->get();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recentActivities->count() > 0): ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0"><?php echo e(__('activity.recent_activities')); ?></h5>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view activity log')): ?>
            <a href="<?php echo e(route('activity-log.index')); ?>" class="btn btn-sm btn-outline-primary">
                <?php echo e(__('activity.view_all')); ?>

            </a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <div class="timeline">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="timeline-item">
                    <div class="timeline-marker">
                        <?php
                            $eventColors = [
                                'created' => 'success',
                                'updated' => 'warning',
                                'deleted' => 'danger',
                                'login' => 'info',
                                'logout' => 'secondary'
                            ];
                            $color = $eventColors[$activity->event] ?? 'primary';
                        ?>
                        <span class="timeline-marker-icon bg-<?php echo e($color); ?>">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php switch($activity->event):
                                case ('created'): ?>
                                    <i class="ti ti-plus"></i>
                                    <?php break; ?>
                                <?php case ('updated'): ?>
                                    <i class="ti ti-edit"></i>
                                    <?php break; ?>
                                <?php case ('deleted'): ?>
                                    <i class="ti ti-trash"></i>
                                    <?php break; ?>
                                <?php case ('login'): ?>
                                    <i class="ti ti-login"></i>
                                    <?php break; ?>
                                <?php case ('logout'): ?>
                                    <i class="ti ti-logout"></i>
                                    <?php break; ?>
                                <?php default: ?>
                                    <i class="ti ti-info-circle"></i>
                            <?php endswitch; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </span>
                    </div>
                    <div class="timeline-content">
                        <div class="timeline-header">
                            <h6 class="timeline-title"><?php echo e($activity->description); ?></h6>
                            <small class="text-muted">
                                <?php echo e($activity->created_at->diffForHumans()); ?>

                            </small>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activity->causer): ?>
                            <div class="timeline-body">
                                <small class="text-muted">
                                    <?php echo e(__('activity.caused_by')); ?>: <?php echo e($activity->causer->name); ?>

                                </small>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php $__env->startPush('styles'); ?>
<style>
.timeline {
    position: relative;
    padding-left: 0;
}

.timeline-item {
    position: relative;
    padding-left: 40px;
    margin-bottom: 20px;
}

.timeline-item:not(:last-child)::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 30px;
    bottom: -20px;
    width: 2px;
    background-color: #e9ecef;
}

.timeline-marker {
    position: absolute;
    left: 0;
    top: 0;
}

.timeline-marker-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    color: white;
    font-size: 12px;
}

.timeline-content {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 12px;
    border-left: 3px solid #dee2e6;
}

.timeline-header {
    display: flex;
    justify-content: between;
    align-items: flex-start;
    margin-bottom: 5px;
}

.timeline-title {
    font-size: 14px;
    margin: 0;
    flex: 1;
    margin-right: 10px;
}

.timeline-body {
    font-size: 12px;
}
</style>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Mohamed Ayman\Herd\hotels\resources\views/admin/components/recent-activities.blade.php ENDPATH**/ ?>